function showInformation(type) {
    var infoDiv = document.getElementById('informacao');
    
    if (type === 'html') {
        infoDiv.innerHTML = `
            <h3>What is HTML?</h3>
            <p>HTML (HyperText Markup Language) is the standard language used to create and structure web pages. It allows you to add content such as text, images, links, and other elements to a page.</p>
            <p>HTML is essential for building websites as it defines the basic structure of a page. Unlike Flutter, HTML is static and relies on additional technologies like CSS and JavaScript to style and make the page interactive.</p>
        `;
    } else if (type === 'flutter') {
        infoDiv.innerHTML = `
            <h3>What is Flutter?</h3>
            <p>Flutter is an open-source framework created by Google for developing natively compiled applications for Android, iOS, and the web with a single codebase. It uses the Dart programming language and provides tools to create rich, performant user interfaces.</p>
            <p>Unlike HTML, which is used for the web, Flutter can be used to create mobile apps and even desktop applications. It allows developers to create applications that work across multiple platforms from the same codebase.</p>
            <p>To learn more about Flutter, visit the <a href="https://flutter.dev" target="_blank">official Flutter website</a>.</p>
        `;
    }
}